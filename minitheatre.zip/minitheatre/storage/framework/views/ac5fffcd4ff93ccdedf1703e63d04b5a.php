<?php $__env->startSection('title'); ?>
Театр
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto my-auto">
    <div class="bg-primary d-flex align-items-center px-3 justify-content-between">
        <div>
            <img src="/img/logo.png" width="150" height="150" alt="big logo">
        </div>
        <div class="fs-1  text-white text-bold me-3">
            Театр
        </div>
    </div>

    <div class="mt-5 d-flex justify-content-center">

        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="true">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>" data-bs-interval="10000">
                    <img src="/img/<?php echo e($event->image); ?>" width="150" height="150" class="d-block w-100" alt="<?php echo e($event->title); ?>">
                    <div class="carousel-caption d-none d-md-block">
                        <h5><?php echo e($event->title); ?></h5>
                        <p><?php echo e($event->age); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\minitheatre\resources\views/about.blade.php ENDPATH**/ ?>