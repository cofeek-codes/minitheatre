<?php $__env->startSection('title'); ?>
Авоська
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto my-auto">
    <div class="bg-primary d-flex align-items-center px-3 justify-content-between">
        <div>
            <img src="/img/logo.png" width="150" height="150" alt="big logo">
        </div>
        <div class="fs-1  text-white text-bold me-3">
            Театр
        </div>
    </div>

    <div class="mt-5 d-flex justify-content-center">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card" style="width: 18rem;">
            <img src="<?php echo e($event->image); ?>" width="300" height="300" class="card-img-top" alt="<?php echo e($event->name); ?>">
            <div class="card-body">
                <h5 class="card-title text-truncate"><?php echo e($event->title); ?></h5>
                <p class="card-text">Цена: <?php echo e($event->price); ?> рублей</p>
                <a href="/cart" class="btn btn-primary">Заказать</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\minitheatre\resources\views/home.blade.php ENDPATH**/ ?>