<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 0; $i < 3; $i++) {

            DB::table('events')->insert([
                'title' => fake()->words(rand(1, 3), true),
                'image' =>  rand(1, 6) . '.jpg',
                'date' => Carbon::now()->subDays(rand(1, 30))->addDays(rand(1, 30))->format('d-m-Y'),
                'age' => fake()->randomElement([0, 3, 6, 12, 16, 18]),
                'genre_id' => rand(1, 3),
            ]);
        }
    }
}
