@extends('base')

@section('title')
register
@endsection

@section('content')
<div class="container">
    <form>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter name">
        </div>

        <div class="form-group">
            <label for="surname">Surname</label>
            <input type="text" class="form-control" id="surname" name="surname" placeholder="Enter surname">
        </div>

        <div class="form-group">
            <label for="patronymic">Patronymic</label>
            <input type="text" class="form-control" id="patronymic" name="patronymic" placeholder="Enter patronymic">
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email"
                aria-describedby="emailHelp" required>
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
        </div>

        <div class="form-group">
            <label for="passwordRepeat">Confirm Password</label>
            <input type="password" class="form-control" id="passwordRepeat" name="password_repeat" placeholder="Confirm password" required>
        </div>

        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="rules" name="rules">
            <label class="form-check-label" for="rules">Accept rules</label>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>
@endsection