@extends('base')

@section('title')
Театр
@endsection

@section('content')
<div class="mx-auto my-auto">
    <div class="bg-primary d-flex align-items-center px-3 justify-content-between">
        <div>
            <img src="/img/logo.png" width="150" height="150" alt="big logo">
        </div>
        <div class="fs-1  text-white text-bold me-3">
            Театр
        </div>
    </div>

    <div class="mt-5 d-flex justify-content-center">

        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="true">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                @foreach ($events as $event)

                <div class="carousel-item @if($loop->first) active @endif" data-bs-interval="10000">
                    <img src="/img/{{$event->image}}" width="150" height="150" class="d-block w-100" alt="{{$event->title}}">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>{{$event->title}}</h5>
                        <p>{{$event->age}}</p>
                    </div>
                </div>
                @endforeach


            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

</div>
@endsection