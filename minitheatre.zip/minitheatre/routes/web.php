<?php

use App\Http\Controllers\AuthController;
use App\Models\Event;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/about', function () {
    return view('about', ['events' => Event::take(5)->get()]);
});


Route::controller(AuthController::class)->group(function () {
    Route::get('/auth/login', 'login');
    Route::get('/auth/logout', 'logout');
    Route::post('/auth/login', 'login');
    Route::get('/auth/register', 'register');
    Route::post('/auth/register', 'register');
});
